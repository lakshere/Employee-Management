module.exports = {
    HOST: "localhost",
    USER: "root",
    PASSWORD: '987laks',
    DB: "employeedb"
  };